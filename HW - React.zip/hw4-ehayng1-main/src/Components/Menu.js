import React from 'react';
/* Add any imports you think you might need here! */

const Menu = () => { 

    return (
      <div className="colorOptions">
          {/* TODO */}
      </div>
    );
}

export default Menu;